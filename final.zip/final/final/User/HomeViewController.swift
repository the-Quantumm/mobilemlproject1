
import SwiftUI
import UIKit
import Firebase

class HomeViewController: UIViewController {

    @IBOutlet weak var welcomeInLabel: UILabel!
    
    @IBOutlet weak var defectButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        let defaults = UserDefaults.standard
                
                Service.getUserInfo(onSuccess: {
                    self.welcomeInLabel.text = "Welcome in \(defaults.string(forKey: "userNameKey")!)"
                }) { (error) in
                    self.present(Service.createAlertController(title: "Error", message: error!.localizedDescription), animated: true, completion: nil)
                }
        
        let button = UIButton(type: .system)
        button.frame = CGRect(x: 0, y: 0, width: 300, height: 100)
        button.backgroundColor = UIColor.blue
        button.setTitleColor(UIColor.white, for: .normal)
        button.setTitle("Проверить дефект", for: .normal)
        button.addTarget(self, action: #selector(nextVC), for: .touchUpInside)
        
        let buttonAnalytics = UIButton(type: .system)
        buttonAnalytics.frame = CGRect(x: 0, y: 0, width: 300, height: 100)
        buttonAnalytics.backgroundColor = UIColor.blue
        buttonAnalytics.setTitleColor(UIColor.white, for: .normal)
        buttonAnalytics.setTitle("Аналитика", for: .normal)
        buttonAnalytics.addTarget(self, action: #selector(analyticVC), for: .touchUpInside)
        
                
                // Добавление кнопки на экран
        
        view.addSubview(button)
        button.center = view.center
        
        buttonAnalytics.frame = CGRect(x: button.frame.origin.x, y: button.frame.origin.y + button.frame.size.height + 150, width: button.frame.size.width, height: button.frame.size.height)
        view.addSubview(buttonAnalytics)
    }
    
    @objc func nextVC(){
        let detectionVC = CameraView()
        let hostingController = UIHostingController(rootView: detectionVC)
        navigationController?.pushViewController(hostingController, animated: true)
        
    }
    
    @objc func analyticVC(){
        let chartVC = AnalyticsView()
        let hostingController = UIHostingController(rootView: chartVC)
        navigationController?.pushViewController(hostingController, animated: true)
        
    }
    

    //@IBAction func defectButton_Clicked(_ sender: Any) {
    //    self.performSegue(withIdentifier: "checkDefect", sender: self)
    //
    //}
    
    @IBAction func logOutButton_Clicked(_ sender: Any) {
        let auth = Auth.auth()
                
                do {
                    try auth.signOut()
                    let defaults = UserDefaults.standard
                    defaults.set(false, forKey: "isUserSignedIN")
                    self.dismiss(animated: true, completion: nil)
                } catch let signOutError {
                    self.present(Service.createAlertController(title: "Ошибка", message: signOutError.localizedDescription), animated: true, completion: nil)
                }
    }
    
}
