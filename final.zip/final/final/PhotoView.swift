

import SwiftUI
import Photos

struct ContentView: View {
    @State var image: Image?
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: PhotoView(image: $image)) {
                    Text("Open Photo")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                if let image = image {
                    image
                        .resizable()
                        .scaledToFit()
                } else {
                    Text("No photo selected")
                }
            }
            .padding()
            .navigationTitle("Home")
        }
    }
}

struct PhotoView: View {
    @Binding var image: Image?
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            if let image = image {
                image
                    .resizable()
                    .scaledToFit()
                
                Text("Фотография сохранена в галлерею.")
                    .font(.title2)
                    .foregroundColor(.white)
                
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    Image(systemName: "arrow.backward")
                })
                .padding(25)
                .foregroundColor(.pink)
                .background(Color.black)
                .cornerRadius(20)
                .frame(width: 350)
            } else {
                ProgressView()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea()
        .background(Color.pink)
        .navigationTitle("Фото")
        .navigationBarTitleDisplayMode(.inline)
    }
}


//import SwiftUI
//import Photos
//
//struct PhotoView: View {
//    @Binding  var image: Image?
//    @Environment(\.presentationMode) var presentationMode
//
//    var body: some View {
//        Group {
//            if let image = image {
//                VStack{
//
//                    image
//                        .resizable()
//                        .scaledToFit()
//
//                    Text("Фотография сохранена в галлерею.")
//                        .font(.title2)
//                        .foregroundColor(Color.white)
//
//
//                    Button(action:{presentationMode.wrappedValue.dismiss()} , label: {
//                        Image(systemName: "arrow.backward")
//                    }).padding(25)
//                        .foregroundColor(.pink)
//                        .background(Color.black)
//                        .cornerRadius(20).frame(width: 350)
//                }
//            } else {
//                ProgressView()
//            }
//        }
//        .frame(maxWidth: .infinity, maxHeight: .infinity)
//        .ignoresSafeArea()
//        .background(Color.pink)
//        .navigationTitle("Фото")
//        .navigationBarTitleDisplayMode(.inline)
//    }
//
//}









//                    NavigationView{
//                        NavigationLink(destination: CameraView(), label:{
//                                    Image(systemName: "arrow.backward")
//                        }).padding(25)
//                        .foregroundColor(.pink)
//                        .background(Color.black)
//                        .cornerRadius(20).frame(width: 350)
//                    }
