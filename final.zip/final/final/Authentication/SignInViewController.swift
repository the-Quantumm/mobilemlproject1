//
//  SignInViewController.swift
//  final
//
//  Created by Мирас on 08.06.2023.
//

import UIKit
import Firebase

class SignInViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    @IBOutlet weak var forgotPasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "bg1")
        let backgroundImageView = UIImageView(image: backgroundImage)
        backgroundImageView.frame = view.bounds
        backgroundImageView.contentMode = .scaleAspectFill
        view.addSubview(backgroundImageView)
        view.sendSubviewToBack(backgroundImageView)

        emailField.delegate = self
        passwordField.delegate = self
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case emailField:
            passwordField.becomeFirstResponder()
        case passwordField:
            passwordField.resignFirstResponder()
            // Выполните здесь необходимые действия, например, нажмите кнопку "Войти"
            signInButton_Clicked(self)
        default:
            break
        }
        return true
    }
    
    @IBAction func signInButton_Clicked(_ sender: Any) {
        let auth = Auth.auth()
        let defaults = UserDefaults.standard
                
        auth.signIn(withEmail: emailField.text!, password: passwordField.text!) { (authResult, error) in
            if error != nil {
                    self.present(Service.createAlertController(title: "Error", message: error!.localizedDescription), animated: true, completion: nil)
                        return
            }
                    
                    defaults.set(true, forKey: "isUserSignedIn")
                    self.performSegue(withIdentifier: "userSignedInSegue", sender: nil)
            }
    }
    
    @IBAction func signUpButton_Clicked(_ sender: Any) {
        self.performSegue(withIdentifier: "signUpSegue", sender: self)
    }
    
    @IBAction func forgotPasswordButton_Clicked(_ sender: Any) {
        self.performSegue(withIdentifier: "forgotPasswordButtonSegue", sender: nil)
    }
    
}
