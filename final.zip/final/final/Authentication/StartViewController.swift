//
//  StartViewController.swift
//  final
//
//  Created by Мирас on 08.06.2023.
//

import UIKit

class StartViewController: UIViewController {

    @IBOutlet weak var startButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "bg1")
        let backgroundImageView = UIImageView(image: backgroundImage)
        backgroundImageView.frame = view.bounds
        backgroundImageView.contentMode = .scaleAspectFill
        view.addSubview(backgroundImageView)
        view.sendSubviewToBack(backgroundImageView)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func startButton_Clicked(_ sender: Any) {
        self.performSegue(withIdentifier: "startButtonSegue", sender: self)
    }
    
    

}
