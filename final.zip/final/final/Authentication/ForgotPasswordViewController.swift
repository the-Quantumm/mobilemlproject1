//
//  ForgotPasswordViewController.swift
//  final
//
//  Created by Мирас on 08.06.2023.
//

import UIKit
import Firebase

class ForgotPasswordViewController: UIViewController {
    
    @IBOutlet weak var emailField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func forgotClicked(_ sender: Any) {
        
        let auth = Auth.auth()
        
        auth.sendPasswordReset(withEmail: emailField.text!) { (error) in
                    if let error = error {
                        let alert = Service.createAlertController(title: "Ошибка", message: error.localizedDescription)
                        self.present(alert, animated: true, completion: nil)
                        return
                    }
                    
                    let alert = Service.createAlertController(title: "Ура", message: "Письмо с восставновлением пароля было отправлено")
                    self.present(alert, animated: true, completion: nil)
                }
       
    }
}
