

import UIKit
import Firebase

class SignUpViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    @IBOutlet weak var signUpButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "bg1")
        let backgroundImageView = UIImageView(image: backgroundImage)
        backgroundImageView.frame = view.bounds
        backgroundImageView.contentMode = .scaleAspectFill
        view.addSubview(backgroundImageView)
        view.sendSubviewToBack(backgroundImageView)

        nameField.delegate = self
        emailField.delegate = self
        passwordField.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case nameField:
            emailField.becomeFirstResponder()
        case emailField:
            passwordField.becomeFirstResponder()
        case passwordField:
            passwordField.resignFirstResponder()
            // Выполните здесь необходимые действия, например, нажмите кнопку "Зарегистрироваться"
            signUpButton_Clicked(self)
        default:
            break
        }
        return true
    }
    
    @IBAction func signUpButton_Clicked(_ sender: Any) {
        
        let defaults = UserDefaults.standard
                
                Service.signUpUser(email: emailField.text!, password: passwordField.text!, name: nameField.text!, onSuccess: {
                    defaults.set(true, forKey: "isUserSignedIn")
                    self.performSegue(withIdentifier: "userSignedUpSegue", sender: nil)
                }) { (error) in
                    self.present(Service.createAlertController(title: "Error", message: error!.localizedDescription), animated: true, completion: nil)
                }
        }
        
        
    }
    
