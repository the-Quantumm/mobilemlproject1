

import UIKit

class WelcomeViewController: UIViewController {
    
    
    @IBOutlet weak var rusLangButton: UIButton!
    
    @IBOutlet weak var kazLangButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "bg1")
        let backgroundImageView = UIImageView(image: backgroundImage)
        backgroundImageView.frame = view.bounds
        backgroundImageView.contentMode = .scaleAspectFill
        view.addSubview(backgroundImageView)
        view.sendSubviewToBack(backgroundImageView)

        let defaults = UserDefaults.standard
                
        if defaults.bool(forKey: "isUserSignedIn") {
            let viewController = self.storyboard?.instantiateViewController(identifier: "welcomeViewID") as! UINavigationController
            viewController.modalTransitionStyle = .crossDissolve
            viewController.modalPresentationStyle = .overFullScreen
            self.present(viewController, animated: true, completion: nil)
        }
    }
    
    @IBAction func rusLangButton_Clicked(_ sender: Any) {
        self.performSegue(withIdentifier: "rusLang", sender: self)
    }
    
    @IBAction func kazLangButton_Clicked(_ sender: Any) {
        self.performSegue(withIdentifier: "kazLang", sender: self)
    }
    

}
