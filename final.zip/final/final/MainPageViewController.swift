//
//  MainPageViewController.swift
//  final
//
//  Created by Мирас on 08.06.2023.
//

import UIKit

class MainPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    

}
