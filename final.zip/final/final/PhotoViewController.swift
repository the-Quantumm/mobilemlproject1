import UIKit

class PhotoViewController: UIViewController {
    var image: UIImage?
    var onDismiss: (() -> Void)?
    
    private let imageView = UIImageView()
    private let titleLabel = UILabel()
    private let backButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = UIColor(red: 255/255, green: 105/255, blue: 180/255, alpha: 1.0)
        
        if let image = image {
            imageView.image = image
            imageView.contentMode = .scaleAspectFit
            view.addSubview(imageView)
            
            titleLabel.text = "Дефект сохранен в галлерею."
            titleLabel.font = UIFont.systemFont(ofSize: 18)
            titleLabel.textColor = .white
            titleLabel.textAlignment = .center
            view.addSubview(titleLabel)
            
            backButton.setImage(UIImage(systemName: "arrow.backward"), for: .normal)
            backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
            backButton.tintColor = UIColor(red: 255/255, green: 105/255, blue: 180/255, alpha: 1.0)
            backButton.backgroundColor = .black
            backButton.layer.cornerRadius = 20
            view.addSubview(backButton)
        } else {
            let progressView = UIProgressView()
            progressView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(progressView)
            
            NSLayoutConstraint.activate([
                progressView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                progressView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
            ])
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        imageView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height * 0.8)
        titleLabel.frame = CGRect(x: 0, y: view.bounds.height * 0.8, width: view.bounds.width, height: 50)
        backButton.frame = CGRect(x: 25, y: view.bounds.height - 80, width: view.bounds.width - 50, height: 60)
    }
    
    @objc private func backButtonTapped() {
        onDismiss?()
        dismiss(animated: true, completion: nil)
    }
}

