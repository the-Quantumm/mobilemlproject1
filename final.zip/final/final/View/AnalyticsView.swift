//
//  AnalyticsView.swift
//  Jasmin
//
//  Created by Мирас on 23.06.2023.
//

import SwiftUI
import UIKit
import Charts


struct AnalyticsView: View {
    
//    let backgroundImage = UIImage(named: "bg1")
//    let backgroundImageView = UIImageView(image: backgroundImage)
//    backgroundImageView.frame = view.bounds
//    backgroundImageView.contentMode = .scaleAspectFill
//    view.addSubview(backgroundImageView)
//    view.sendSubviewToBack(backgroundImageView)
    
    let viewMonths: [ViewMonth] = [
        .init(dates: Date.from(year: 2023, month: 1, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 2, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 3, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 4, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 5, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 6, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 7, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 8, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 9, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 10, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 11, day: 1), viewCount: Int.random(in: 10...100)),
        .init(dates: Date.from(year: 2023, month: 12, day: 1), viewCount: Int.random(in: 10...100))
    ]
    var body: some View {
        VStack{
            Chart{
                
                RuleMark(y: .value("Норма", 50))
                    .foregroundStyle(Color.mint)
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                    .annotation(alignment: .leading) {
                        Text("Норма")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                
                
                ForEach(viewMonths){ viewMonths in
                    BarMark(
                        x: .value("Месяц", viewMonths.dates, unit: .month),
                        y: .value("Дефекты", viewMonths.viewCount)
                    )
                }
            }
            .frame(height: 180)
            .chartPlotStyle { plotContent in
                plotContent
                    .background(.mint.gradient.opacity(0.2))
                
            }
        }
    }
}

struct AnalyticsView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyticsView()
    }
}

struct ViewMonth: Identifiable {
    let id = UUID()
    let dates: Date
    let viewCount: Int
}

extension Date {
    static func from(year: Int, month: Int, day: Int) -> Date{
        let components = DateComponents(year: year, month: month, day: day)
        return Calendar.current.date(from: components)!
    }
}
